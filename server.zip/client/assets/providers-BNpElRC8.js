import{j as e,bA as o}from"./main-BEQDklCn.js";import{u as t}from"./use-page-title-Djs5JW3m.js";const i=function(){return t("Provider Setup"),e.jsx(o,{})};export{i as component};
