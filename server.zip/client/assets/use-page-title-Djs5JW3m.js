import{r}from"./main-BEQDklCn.js";const e="Hermes Workspace";function s(t){r.useEffect(()=>(document.title=t?`${t} — ${e}`:e,()=>{document.title=e}),[t])}export{s as u};
