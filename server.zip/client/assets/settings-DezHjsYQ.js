import{j as t,ac as o}from"./main-BEQDklCn.js";const s=function(){return t.jsx(o,{})};export{s as component};
